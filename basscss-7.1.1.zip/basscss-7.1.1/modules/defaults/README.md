# Basscss Defaults

Default custom property variables and custom media queries for [Basscss](http://basscss.com).


